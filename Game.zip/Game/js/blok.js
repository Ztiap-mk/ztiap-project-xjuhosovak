class Blok {
    // Initialization
    constructor() {
        this.canvas = document.getElementById("canvas");
        this.image = resourceManager.getImageSource('blok');
    
        this.x = 0
        this.y = 0
        this.dx = 0
        this.dy = 0
        
    }
  
    // Movement logic
    // move(dt) tu treba nechat, aj ked prazdne, lebo inak to nefunguje
    move(dt) {
	   
    } 
  
    // Render self
    draw(ctx) {
      ctx.save()
          
      ctx.drawImage(this.image, 100,100,50,50)
      ctx.drawImage(this.image, 150,100,50,50)
      ctx.drawImage(this.image, 200,100,50,50) 

      ctx.drawImage(this.image, 300,400,50,50)
      ctx.drawImage(this.image, 350,400,50,50)
      ctx.drawImage(this.image, 250,400,50,50) 

      ctx.drawImage(this.image, 400,250,50,50)
      ctx.drawImage(this.image, 450,250,50,50)
      ctx.drawImage(this.image, 350,250,50,50)

      ctx.drawImage(this.image, 100,500,50,50) 
      ctx.drawImage(this.image, 50,500,50,50)
      
        
      ctx.restore()
    }
}