gameover = function() {
    var sceneObjects = []
    sceneObjects.push(new Background("gameover") );
     sceneObjects.push(new Button('level', 130,250,280,80, "play") );
     sceneObjects.push(new Button('instructions', 130,350,280,80, "instructions") );
     sceneObjects.push(new Button('sound',240,450,60,60, "sound") );
  
    return sceneObjects;
  };