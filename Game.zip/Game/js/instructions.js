instructions = function() {
  var sceneObjects = []
  sceneObjects.push(new Background("instrukcie") );
   sceneObjects.push(new Button('menu',0,0,60,60, "home") );

  return sceneObjects;
};