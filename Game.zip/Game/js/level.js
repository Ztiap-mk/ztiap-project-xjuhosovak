level = function() {
  var sceneObjects = []
  sceneObjects.push(new Background("pozadie") );
  sceneObjects.push(new Button('menu',0,0,60,60, "home") );
	sceneObjects.push(new Button('sound',490,0,60,60, "sound") );	
  
  sceneObjects.push(new Blok() );
  sceneObjects.push(new Star());
  sceneObjects.push(new Netopier());
		
  return sceneObjects;
};