

const resourceManager = new ResourceManager();


window.onmousemove = function (event){
  game.onmousemove(event);
}
window.onmousedown = function (event){
  game.onmousedown(event);
}
window.onmouseup = function (event){
  game.onmouseup(event);
}
window.onkeydown = function (event){
  game.onkeydown(event);
}
window.onkeyup = function (event){
  game.onkeyup(event);
}

const game = new Game();
    game.start();


