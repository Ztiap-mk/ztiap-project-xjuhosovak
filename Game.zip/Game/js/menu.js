menu = function() {
  var sceneObjects = []
  sceneObjects.push(new Background("black") );
   sceneObjects.push(new Button('level', 130,300,280,80, "play") );
   sceneObjects.push(new Button('instructions', 130,400,280,80, "instructions") );
   sceneObjects.push(new Button('sound',240,550,60,60, "sound") );

  return sceneObjects;
};