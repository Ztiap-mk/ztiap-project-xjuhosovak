class Netopier {
    // Initialization
    constructor() {
        this.canvas = document.getElementById("canvas");
        this.image = resourceManager.getImageSource('netopier');
    
        this.x = canvas.width/2
        this.y = canvas.height
        this.dx = 0// toto sa meni podla klavesy
        this.dy = -1 // gravity
        this.size = 0.7
     

    }
  
    // Movement logic
    move(dt) { 
        const canvas = this.canvas;
      
        if (this.y > canvas.height) {
            this.y = canvas.height
            this.dy = -1
        }
        if (this.y < 0) {
            //this.y = canvas.height
            //this.dy = -1
            game.objects = gameover();
        }
        if (this.x < 70){
          this.x = 70
        }
        if (this.x > canvas.width){
          this.x = canvas.width
        }
        
    
        // Movement
        if( game.keys[39]){ //ked je stlacena prava sipka
            this.x += +10;
          }
          if(game.keys[37]){ //lava sipka
            this.x += -10;
          }
        this.y += this.dy * dt
    }
  
    // Render self
    draw(ctx) {
      ctx.save()
      ctx.translate(this.x, this.y)
      ctx.scale(this.size, this.size)
      ctx.drawImage(this.image, -100, -100, 100, 70)  
      ctx.restore()
    }
}