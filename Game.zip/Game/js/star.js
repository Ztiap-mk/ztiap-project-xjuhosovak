class Star {
    // Initialization
    constructor() {
        this.canvas = document.getElementById("canvas");
        this.image = resourceManager.getImageSource('star');
    
        this.x = 0
        this.y = 0
        this.dx = 0
        this.dy = 0
        
    }
  
    // Movement logic
    // move(dt) tu treba nechat, aj ked prazdne, lebo inak to nefunguje
    move(dt) {
	   
    } 
  
    // Render self
    draw(ctx) {
      ctx.save()
          
      ctx.drawImage(this.image, 200,300,30,30)
      ctx.drawImage(this.image, 350,200,30,30)  
      ctx.drawImage(this.image, 50,100,30,30)
     ctx.drawImage(this.image, 450,400,30,30) 
     ctx.drawImage(this.image, 150,600,30,30) 
        
      ctx.restore()
    }
}